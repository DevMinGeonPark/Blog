/**
 * 대화 내역 번역 프롬프트 생성 모듈
 * 이메일 대화 내역에서 최신 메시지를 번역하기 위한 프롬프트를 생성
 */

import { commonGuidelines } from './commonGuidelines.js';
// 대화 내역 처리 규칙
const conversationRules = {
    messageBoundary: {
        format: "- Look for lines starting with a date and email format (e.g., \"2025년 3월 14일 오전 7:25에, Hirediversity <support@hirediversity.club>가 작성하였습니다:\")",
        purpose: "- These lines indicate the start of a message",
        target: "- Find the most recent message (the one before the first date+email line)",
        action: "- Translate ONLY that most recent message"
    },
    fallback: {
        noBoundary: "- If you can't find a clear message boundary, translate the entire text",
        invalid: "- If the text is meaningless or strange, return \"자체번역을 이용하세요\""
    },
    formatting: {
        noNotes: "- Do not add any explanations, notes, or additional text",
        preserveFormat: "- Maintain the original formatting and line breaks",
        noBrackets: "- Do not include the square brackets [ ] in the translation",
        contentOnly: "- Translate only the text inside the square brackets"
    }
};
// 예시 텍스트
const exampleText = {
    input: `[2025년 3월 14일 오전 7:25에, Hirediversity <support@hirediversity.club>가 작성하였습니다:
Previous message content...


2025년 3월 14일 오전 7:20에, User <user@example.com>가 작성하였습니다:
Latest message to translate]`,
    output: "최신 메시지 번역 결과"
};
/**
 * 대화 내역 번역 프롬프트 생성 함수
 * @param {string} query - 번역할 대화 내역 텍스트
 * @returns {Array} - ChatGPT API에 전달할 메시지 배열
 */
export function createLatentPrompt(query) {
    const systemMessage = {
        role: "system",
        content: `You are a translation machine specialized in handling conversation history. Translate the latest message to Korean.

IMPORTANT: 
${conversationRules.messageBoundary.format}
${conversationRules.messageBoundary.purpose}
${conversationRules.messageBoundary.target}
${conversationRules.messageBoundary.action}
${conversationRules.fallback.noBoundary}
${conversationRules.fallback.invalid}
${conversationRules.formatting.noNotes}
${conversationRules.formatting.preserveFormat}
${conversationRules.formatting.noBrackets}
${conversationRules.formatting.contentOnly}

${commonGuidelines.formatting.lineBreaks}
${commonGuidelines.formatting.spacing}
${commonGuidelines.formatting.emphasis}
${commonGuidelines.content.preserve}
${commonGuidelines.content.style}
${commonGuidelines.content.wordUsage}
${commonGuidelines.instructions.exclude}

Example input: ${exampleText.input}

Example output: "${exampleText.output}"`
    };

    const userMessage = {
        role: "user",
        content: `[${query}]`
    };

    return [systemMessage, userMessage];
} 