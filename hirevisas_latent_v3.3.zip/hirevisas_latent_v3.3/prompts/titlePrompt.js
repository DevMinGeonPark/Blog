/**
 * 이메일 제목 번역 프롬프트 생성 모듈
 * 영어 이메일 제목을 한국어로 번역하기 위한 프롬프트를 생성
 */
import { commonGuidelines } from './commonGuidelines.js';

// 이메일 제목 번역 규칙
const titleTranslationRules = {
    basic: "1. Translate the given title from English to Korean naturally and concisely",
    rePrefix: {
        count: "2. For titles with multiple \"Re:\" prefixes:",
        multiple: "   - Count the number of \"Re:\" occurrences",
        replace: "   - Replace them with \"Re{count}:\" if count > 1 (e.g., \"Re: Re: Re:\" becomes \"Re3:\")",
        single: "   - Keep single \"Re:\" as is"
    },
    preserve: {
        numbers: "3. Maintain any reference numbers, ticket IDs, or special markers",
        technical: "4. Keep technical terms that should not be translated",
        special: "5. Preserve any emojis or special characters"
    }
};

// 예시 텍스트
const exampleText = {
    input: "Re: Re: Re: Urgent: API Integration Issue #1234",
    output: "Re3: **긴급**: API 통합 이슈 #1234"
};

/**
 * 이메일 제목 번역 프롬프트 생성 함수
 * @param {string} text - 번역할 이메일 제목
 * @returns {Array} - ChatGPT API에 전달할 메시지 배열
 */
export function createTitlePrompt(text) {
    const systemMessage = {
        role: "system",
        content: `You are a professional translator specializing in email subject lines.
Follow these guidelines:
${titleTranslationRules.basic}
${titleTranslationRules.rePrefix.count}
${titleTranslationRules.rePrefix.multiple}
${titleTranslationRules.rePrefix.replace}
${titleTranslationRules.rePrefix.single}
${titleTranslationRules.preserve.numbers}
${titleTranslationRules.preserve.technical}
${titleTranslationRules.preserve.special}

${commonGuidelines.formatting.lineBreaks}
${commonGuidelines.formatting.spacing}
${commonGuidelines.formatting.emphasis}
${commonGuidelines.content.preserve}
${commonGuidelines.content.style}
${commonGuidelines.content.wordUsage}
${commonGuidelines.instructions.exclude}

IMPORTANT: 
${commonGuidelines.important}

Example:
Input: "${exampleText.input}"
Output: "${exampleText.output}"`
    };

    const userMessage = {
        role: "user",
        content: `Please translate the following title: ${text}`
    };

    return [systemMessage, userMessage];
} 