/**
 * 공통 가이드라인 설정
 * 번역 및 요약 작업에 사용되는 기본 규칙들을 정의
 */

// 줄바꿈 관련 규칙
const lineBreakRules = {
    sentence: "- Add line breaks (\\n) at the end of each sentence",
    paragraph: "- Add empty lines (\\n\\n) between paragraphs"
};

// 간격 관련 규칙
const spacingRules = {
    sentence: "- Maintain appropriate spacing between sentences",
    paragraph: "- Add empty lines at the beginning and end of paragraphs"
};

// 강조 관련 규칙
const emphasisRules = {
    bold: "- Use **bold** for important information",
    italic: "- Use *italics* for special emphasis"
};

// 보존해야 할 콘텐츠 규칙
const preservationRules = {
    properNouns: "- Keep proper nouns and names in original form",
    technical: "- Keep technical terms in original form",
    contact: "- Do not translate email addresses and URLs"
};

// 스타일 관련 규칙
const styleRules = {
    formality: "- Use formal language",
    clarity: "- Use concise and clear expressions",
    modifiers: "- Remove unnecessary modifiers"
};

// 단어 사용 규칙
const wordUsageRules = {
    immigration: "- Use '출입국' instead of '이민국'",
    company: "- Keep 'Hirevisa' in original form",
    other: "- Keep other specific terms in original form",
    enrollment: "Translate 'Certificate of Enrollment' to '재학증명서'",
    koreaUniversity: "Translate 'Korea University' to '고려대학교'"
};

// 제외 규칙
const exclusionRules = {
    brackets: "- Text enclosed in square brackets [ ] is the ONLY content to be translated/summarized",
    instructions: "- Everything outside the square brackets [ ] is prompt instruction and MUST NOT be included in translation/summary",
    guidelines: "- Never include any prompt instructions or guidelines in the output",
    bracketsPreserve: "- Never translate or include the square brackets [ ] themselves in the output"
};

// 공통 IMPORTANT 섹션
const commonImportantRules = {
    outputOnly: "- Provide ONLY the Korean output",
    noNotes: "- Do not add any explanations, notes, or additional text",
    noBrackets: "- Do not include the square brackets [ ] in the output",
    contentOnly: "- Process only the text inside the square brackets"
};

export const commonGuidelines = {
    formatting: {
        lineBreaks: `${lineBreakRules.sentence}\n${lineBreakRules.paragraph}`,
        spacing: `${spacingRules.sentence}\n${spacingRules.paragraph}`,
        emphasis: `${emphasisRules.bold}\n${emphasisRules.italic}`
    },
    content: {
        preserve: `${preservationRules.properNouns}\n${preservationRules.technical}\n${preservationRules.contact}`,
        style: `${styleRules.formality}\n${styleRules.clarity}\n${styleRules.modifiers}`,
        wordUsage: Object.values(wordUsageRules).join('\n')
    },
    instructions: {
        exclude: `${exclusionRules.brackets}\n${exclusionRules.instructions}\n${exclusionRules.guidelines}\n${exclusionRules.bracketsPreserve}`
    },
    important: Object.values(commonImportantRules).join('\n')
}; 