/**
 * 프롬프트 생성 모듈
 * 다양한 유형의 프롬프트를 생성하는 메인 모듈
 */

import { createSummaryPrompt } from './summaryPrompt.js';
import { createLatentPrompt } from './latentPrompt.js';
import { createTranslationPrompt } from './translationPrompt.js';
import { createTitlePrompt } from './titlePrompt.js';

/**
 * 프롬프트 생성 함수
 * @param {string} query - 프롬프트에 사용할 텍스트
 * @param {string} type - 프롬프트 유형 (summary, latent, translation, title)
 * @returns {Array} - ChatGPT API에 전달할 메시지 배열
 */
export function createPrompt(query, type) {
    // 프롬프트 유형별 생성 함수 매핑
    const prompts = {
        summary: () => createSummaryPrompt(query),
        latent: () => createLatentPrompt(query),
        translation: () => createTranslationPrompt(query),
        title: () => createTitlePrompt(query)
    };

    // 지정된 유형의 프롬프트가 있으면 해당 프롬프트를, 없으면 번역 프롬프트를 반환
    return prompts[type] ? prompts[type]() : prompts.translation();
} 