/**
 * 텍스트 요약 프롬프트 생성 모듈
 * 긴 텍스트를 한국어로 간단히 요약하기 위한 프롬프트를 생성
 */

import { commonGuidelines } from './commonGuidelines.js';

// 요약 작업에 필요한 추가 가이드라인
const summaryRules = {
    content: {
        exclude: "- Exclude greetings, thank you messages, and formal phrases",
        focus: "- Summarize only actual inquiries or requests",
        length: "- Explain key points in 1-2 sentences",
        language: "- Provide summary in Korean only"
    },
    style: {
        technical: "- Explain technical terms in simple terms",
        formality: "- Use formal language"
    }
};

// 예시 텍스트
const exampleText = {
    visa: "**비자 신청 절차**에 문의함.\\n\\n",
    requirements: "**영어 성적 증명서**가 필요하며, **다음 달까지** 제출해야함.\\n\\n",
    additional: "추가로 **재직 증명서**도 필요"
};

export const summaryGuidelines = {
    format: Object.values(summaryRules.content).concat(Object.values(summaryRules.style)).join('\n'),
    example: `${exampleText.visa}${exampleText.requirements}${exampleText.additional}`
};

/**
 * 요약 프롬프트 생성 함수
 * @param {string} query - 요약할 텍스트
 * @returns {Array} - ChatGPT API에 전달할 메시지 배열
 */
export function createSummaryPrompt(query) {
    const systemMessage = {
        role: "system",
        content: `You are a Korean summarization machine. Summarize the given text in Korean.
${summaryGuidelines.format}
${commonGuidelines.formatting.lineBreaks}
${commonGuidelines.formatting.spacing}
${commonGuidelines.formatting.emphasis}
${commonGuidelines.content.preserve}
${commonGuidelines.content.style}
${commonGuidelines.content.wordUsage}
${commonGuidelines.instructions.exclude}

IMPORTANT: 
${commonGuidelines.important}

Example input: [Original long text]
Example output: "${summaryGuidelines.example}"`
    };

    const userMessage = {
        role: "user",
        content: `[${query}]`
    };

    return [systemMessage, userMessage];
} 