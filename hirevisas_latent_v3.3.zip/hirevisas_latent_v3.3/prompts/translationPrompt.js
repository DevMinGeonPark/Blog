/**
 * 번역 프롬프트 생성 모듈
 * 영어 텍스트를 한국어로 번역하기 위한 프롬프트를 생성
 */

import { commonGuidelines } from './commonGuidelines.js';

// 번역 작업에 필요한 추가 가이드라인
const formatRules = {
    lineBreaks: "- Maintain original line breaks and spacing",
    structure: "- Keep original paragraph structure",
    sentenceEnd: "- Add line break after sentences ending with period",
    specialCases: "- Add line break after greetings, closings, and list items",
    listFormat: "- Use bullet points (•) for list items",
    quotes: "- Use quotes for important terms",
    clarity: "- Present translation in understandable form"
};

// 예시 텍스트
const exampleText = {
    greeting: "안녕하세요.\\n반갑습니다.\\n\\n오늘은 좋은 날씨입니다."
};

export const translationGuidelines = {
    format: Object.values(formatRules).join('\n'),
    example: exampleText.greeting
};

/**
 * 번역 프롬프트 생성 함수
 * @param {string} query - 번역할 텍스트
 * @returns {Array} - ChatGPT API에 전달할 메시지 배열
 */
export function createTranslationPrompt(query) {
    const systemMessage = {
        role: "system",
        content: `You are a translation machine. Translate the given text to Korean.

${translationGuidelines.format}

${commonGuidelines.formatting.lineBreaks}
${commonGuidelines.formatting.spacing}
${commonGuidelines.formatting.emphasis}
${commonGuidelines.content.preserve}
${commonGuidelines.content.style}
${commonGuidelines.content.wordUsage}
${commonGuidelines.instructions.exclude}

IMPORTANT: 
${commonGuidelines.important}

Example input: [Original text]
Example output: "${translationGuidelines.example}"`
    };

    const userMessage = {
        role: "user",
        content: `[${query}]`
    };

    return [systemMessage, userMessage];
} 