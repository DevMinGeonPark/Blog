console.log("Content script loaded on Freshdesk site!");

// 상태 관리 변수들
let isTranslationCompleted = false;
let isExtensionValid = true;
let insertAttempts = 0;
const MAX_INSERT_ATTEMPTS = 5;
let isSidebarOpen = false;

// 메시지 처리 상태 관리
let messageProcessingState = {
    isProcessing: false,
    lastProcessedTime: null,
    retryCount: 0,
    maxRetries: 3
};

// CSS 스타일 수정
const styles = `
    @keyframes rotate {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
    }
    
    .translation-loading {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 10px;
        padding: 10px;
        background-color: #f5f5f5;
        border-left: 4px solid #FFA500;
    }
    
    .loading-spinner {
        width: 20px;
        height: 20px;
        border: 3px solid #f3f3f3;
        border-top: 3px solid #3498db;
        border-radius: 50%;
        animation: rotate 1s linear infinite;
    }
    
    .korean-translation {
        margin-bottom: 10px;
        padding: 10px;
        background-color: #f5f5f5;
        border-left: 4px solid #4CAF50;
        font-size: 16px;
        line-height: 1.5;
        white-space: pre-wrap;
        opacity: 0;
        transition: opacity 0.3s ease-in-out;
    }
    
    .korean-translation.show {
        opacity: 1;
    }

    #translation-sidebar {
        position: fixed;
        right: -400px;
        top: 0;
        width: 400px;
        height: 100vh;
        background-color: white;
        box-shadow: -2px 0 5px rgba(0,0,0,0.1);
        z-index: 10000;
        transition: right 0.3s ease-in-out;
        display: flex;
        flex-direction: column;
    }

    #translation-sidebar.open {
        right: 0;
    }

    .sidebar-header {
        padding: 15px;
        background-color: #f8f9fa;
        border-bottom: 1px solid #dee2e6;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .sidebar-header h2 {
        margin: 0;
        font-size: 16px;
        font-weight: 600;
        color: #333;
    }

    .sidebar-content {
        flex: 1;
        overflow-y: auto;
        padding: 15px;
        font-size: 16px;
    }

    .sidebar-close {
        cursor: pointer;
        font-size: 18px;
        color: #666;
    }

    .translation-section {
        margin-bottom: 20px
        padding: 15px;
        background-color: #f8f9fa;
        border-radius: 5px;
    }

    .translation-section h3 {
        margin-top: 0;
        color: #333;
        font-size: 15px;
    }

    .selected-text {
        background-color: #e3f2fd;
        padding: 2px 5px;
        border-radius: 3px;
    }

    .translate-button {
        position: fixed;
        bottom: 20px;
        right: 20px;
        background-color: #4CAF50;
        color: white;
        border: none;
        padding: 10px 20px;
        border-radius: 5px;
        cursor: pointer;
        z-index: 10000;
        display: none;
        box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    }

    .translate-button:hover {
        background-color: #45a049;
    }

    .translation-content, .summary-content {
        margin-bottom: 10px;
        padding: 10px;
        background-color: #f5f5f5;
        border-left: 4px solid #4CAF50;
        font-size: 12px;
        line-height: 1.5;
        white-space: pre-wrap;
        opacity: 0;
        transition: opacity 0.3s ease-in-out;
    }

    .translation-content.show, .summary-content.show {
        opacity: 1;
    }

    /* 마크다운 스타일 */
    .translation-content strong, .summary-content strong,
    .translation-content b, .summary-content b {
        font-weight: bold;
        color: #2c3e50;
    }

    .translation-content em, .summary-content em,
    .translation-content i, .summary-content i {
        font-style: italic;
    }

    .translation-content code, .summary-content code {
        background-color: #f8f9fa;
        padding: 2px 4px;
        border-radius: 3px;
        font-family: monospace;
    }

    .translation-content pre, .summary-content pre {
        background-color: #f8f9fa;
        padding: 10px;
        border-radius: 4px;
        overflow-x: auto;
    }

    .translation-content blockquote, .summary-content blockquote {
        border-left: 4px solid #ddd;
        margin: 10px 0;
        padding-left: 10px;
        color: #666;
    }

    .translation-content ul, .summary-content ul,
    .translation-content ol, .summary-content ol {
        margin: 10px 0;
        padding-left: 20px;
    }

    .translation-content li, .summary-content li {
        margin: 5px 0;
    }

    .translation-content a, .summary-content a {
        color: #3498db;
        text-decoration: none;
    }

    .translation-content a:hover, .summary-content a:hover {
        text-decoration: underline;
    }

    .translated-title {
        margin-top: 5px;
        color: #666;
        font-weight: bold;
        font-size: 1.2em;
    }

    .sidebar-footer {
        padding: 10px 15px;
        background-color: #f8f9fa;
        border-top: 1px solid #dee2e6;
        text-align: right;
        font-size: 10px;
        color: #666;
    }
`;

// 스타일 삽입
function insertStyles() {
    const styleSheet = document.createElement("style");
    styleSheet.textContent = styles;
    document.head.appendChild(styleSheet);
}

// 사이드바 생성 함수
function createSidebar() {
    const sidebar = document.createElement('div');
    sidebar.id = 'translation-sidebar';
    sidebar.innerHTML = `
        <div class="sidebar-header">
            <h2>번역 도우미</h2>
            <span class="sidebar-close">&times;</span>
        </div>
        <div class="sidebar-content">
            <div class="translation-section">
                <h3>요약</h3>
                <div id="summary-result"></div>
            </div>
            <div class="translation-section">
                <h3>번역 결과</h3>
                <div id="translation-result"></div>
            </div>
        </div>
        <div class="sidebar-footer">
            Created by Mingeon Park
        </div>
    `;
    document.body.appendChild(sidebar);

    // 닫기 버튼 이벤트
    sidebar.querySelector('.sidebar-close').addEventListener('click', () => {
        toggleSidebar();
    });

    return sidebar;
}

// 사이드바 토글 함수
function toggleSidebar() {
    const sidebar = document.getElementById('translation-sidebar');
    if (sidebar) {
        isSidebarOpen = !isSidebarOpen;
        sidebar.classList.toggle('open');
    }
}

// 번역 버튼 생성 함수
function createTranslateButton() {
    const button = document.createElement('button');
    button.className = 'translate-button';
    button.textContent = '번역하기';
    document.body.appendChild(button);
    return button;
}

// 텍스트 선택 이벤트 처리
function handleTextSelection(event) {
    // 사이드바 내에서의 선택인지 확인
    const sidebar = document.getElementById('translation-sidebar');
    if (sidebar && sidebar.contains(event.target)) {
        console.log('사이드바 내의 선택 무시');
        return;
    }

    const selection = window.getSelection();
    if (!selection.rangeCount) return;
    
    const range = selection.getRangeAt(0);
    const container = document.querySelector('#ticket_original_request');
    
    // 선택된 영역이 #ticket_original_request 내부인지 확인
    if (!container || !container.contains(range.commonAncestorContainer)) {
        console.log('ticket_original_request 외부의 선택 무시');
        return;
    }
    
    // 선택된 텍스트의 원본 형식을 보존하기 위해 HTML 내용을 가져옴
    const tempDiv = document.createElement('div');
    tempDiv.appendChild(range.cloneContents());
    
    // 줄바꿈을 보존하면서 텍스트 추출
    let selectedText = tempDiv.innerHTML
        .replace(/<br\s*\/?>/gi, '\n') // <br> 태그를 줄바꿈으로 변환
        .replace(/<p>/gi, '') // <p> 태그 시작 제거
        .replace(/<\/p>/gi, '\n') // <p> 태그 끝을 줄바꿈으로 변환
        .replace(/<div>/gi, '') // <div> 태그 시작 제거
        .replace(/<\/div>/gi, '\n') // <div> 태그 끝을 줄바꿈으로 변환
        .replace(/<[^>]+>/g, '') // 나머지 HTML 태그 제거
        .replace(/&nbsp;/g, ' ') // &nbsp;를 공백으로 변환
        .replace(/\n\s*\n/g, '\n\n') // 연속된 줄바꿈 정리
        .trim(); // 앞뒤 공백 제거
    
    if (selectedText) {
        // 한국어 감지 (한글 정규식)
        const koreanRegex = /[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/;
        if (koreanRegex.test(selectedText)) {
            console.log('한국어 텍스트 감지됨, 번역 무시');
            return;
        }

        // 텍스트 길이 체크
        if (selectedText.length > 3000) {
            alert('번역할 수 있는 최대 텍스트 길이는 3000자입니다. 더 짧은 텍스트를 선택해주세요.');
            return;
        }
        
        // 선택한 텍스트 처리
        processSelectedText(selectedText);
    }
}

// 선택한 텍스트 처리 함수
async function processSelectedText(text) {
    const sidebar = document.getElementById('translation-sidebar');
    if (!sidebar) return;

    // 로딩 표시
    document.getElementById('translation-result').innerHTML = '<div class="translation-loading"><div class="loading-spinner"></div><span>번역 중...</span></div>';
    document.getElementById('summary-result').innerHTML = '<div class="translation-loading"><div class="loading-spinner"></div><span>요약 중...</span></div>';

    // 사이드바 열기
    if (!isSidebarOpen) {
        toggleSidebar();
    }

    // 타임아웃 설정
    const timeout = 30000; // 30초로 증가
    const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => {
            reject(new Error('timeout'));
        }, timeout);
    });

    try {
        // 번역과 요약 요청을 동시에 처리
        const [translationResponse, summaryResponse] = await Promise.all([
            Promise.race([
                sendMessageToBackground({
                    action: "queryChatGPT",
                    query: text,
                    type: 'individual_translation',
                    isSidebarTranslation: true
                }),
                timeoutPromise
            ]),
            Promise.race([
                sendMessageToBackground({
                    action: "queryChatGPT",
                    query: text,
                    type: 'summary',
                    isSidebarTranslation: true
                }),
                timeoutPromise
            ])
        ]);

        console.log("Received responses:", { translation: translationResponse, summary: summaryResponse });

        // 번역 결과 처리
        if (translationResponse && translationResponse.success && translationResponse.translation) {
            const translationResult = document.getElementById('translation-result');
            if (translationResult) {
                const loadingIndicator = translationResult.querySelector('.translation-loading');
                if (loadingIndicator) {
                    loadingIndicator.remove();
                }
                if (translationResponse.translation && typeof translationResponse.translation === 'string') {
                    // 마크다운을 HTML로 변환
                    const htmlContent = translationResponse.translation
                        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') // 볼드
                        .replace(/\*(.*?)\*/g, '<em>$1</em>') // 이탤릭
                        .replace(/`(.*?)`/g, '<code>$1</code>') // 코드
                        .replace(/\n/g, '<br>'); // 줄바꿈
                    
                    const contentDiv = document.createElement('div');
                    contentDiv.className = 'translation-content';
                    contentDiv.innerHTML = htmlContent;
                    contentDiv.classList.add('show');
                    
                    translationResult.innerHTML = '';
                    translationResult.appendChild(contentDiv);
                    console.log("번역 결과 표시 완료:", translationResponse.translation);
                } else {
                    throw new Error("Invalid translation result format");
                }
            }
        }

        // 요약 결과 처리
        if (summaryResponse && summaryResponse.success && summaryResponse.translation) {
            const summaryResult = document.getElementById('summary-result');
            if (summaryResult) {
                const loadingIndicator = summaryResult.querySelector('.translation-loading');
                if (loadingIndicator) {
                    loadingIndicator.remove();
                }
                if (summaryResponse.translation && typeof summaryResponse.translation === 'string') {
                    // 마크다운을 HTML로 변환
                    const htmlContent = summaryResponse.translation
                        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') // 볼드
                        .replace(/\*(.*?)\*/g, '<em>$1</em>') // 이탤릭
                        .replace(/`(.*?)`/g, '<code>$1</code>') // 코드
                        .replace(/\n/g, '<br>'); // 줄바꿈
                    
                    const contentDiv = document.createElement('div');
                    contentDiv.className = 'summary-content';
                    contentDiv.innerHTML = htmlContent;
                    contentDiv.classList.add('show');
                    
                    summaryResult.innerHTML = '';
                    summaryResult.appendChild(contentDiv);
                    console.log("요약 결과 표시 완료:", summaryResponse.translation);
                } else {
                    throw new Error("Invalid summary result format");
                }
            }
        }
    } catch (error) {
        // 타임아웃 에러 처리
        if (error.message === 'timeout') {
            const errorMessage = `
                <div style="color: #d32f2f; padding: 15px; background-color: #ffebee; border-radius: 4px;">
                    <p>번역 요청 처리 시간이 초과되었습니다.</p>
                    <p>잠시 후 다시 시도해주시기 바랍니다.</p>
                    <p>계속해서 문제가 발생하면 페이지를 새로고침 해주세요.</p>
                </div>`;
            document.getElementById('translation-result').innerHTML = errorMessage;
            document.getElementById('summary-result').innerHTML = errorMessage;
        } else {
            const errorMessage = `
                <div style="color: #d32f2f; padding: 15px; background-color: #ffebee; border-radius: 4px;">
                    <p>오류가 발생했습니다: ${error.message}</p>
                </div>`;
            document.getElementById('translation-result').innerHTML = errorMessage;
            document.getElementById('summary-result').innerHTML = errorMessage;
        }
    }
}

// 초기화 함수
function initialize() {
    insertStyles();
    createSidebar();

    // 텍스트 선택 이벤트 리스너
    document.addEventListener('mouseup', handleTextSelection);
}

// DOM이 로드된 후 실행
window.addEventListener('load', () => {
    console.log("Window loaded");
    initialize();
});

// 로딩 인디케이터 생성
function createLoadingIndicator() {
    const loadingDiv = document.createElement('div');
    loadingDiv.className = 'translation-loading';
    
    const spinner = document.createElement('div');
    spinner.className = 'loading-spinner';
    
    const text = document.createElement('span');
    text.textContent = '번역 중...';
    
    loadingDiv.appendChild(spinner);
    loadingDiv.appendChild(text);
    
    return loadingDiv;
}

// 확장 프로그램 컨텍스트 유효성 체크
function checkExtensionContext() {
    try {
        return !!(chrome.runtime && chrome.runtime.id);
    } catch (e) {
        console.log('Extension context is invalid');
        return false;
    }
}

// 대상 요소 찾기 함수 수정
function findTargetElement() {
    const container = document.querySelector('#ticket_original_request');
    if (!container) {
        console.log('Ticket container not found');
        return null;
    }

    // 2. data-identifyelement 속성을 가진 연속된 div들 찾기
    const identifyElements = Array.from(container.children).filter(child => {
        // 직계 자식이면서 data-identifyelement 속성을 가진 div만 선택
        return child.tagName === 'DIV' && child.hasAttribute('data-identifyelement');
    });

    console.log('identifyElements:', identifyElements);

    if (identifyElements.length > 0) {
        // 연속된 요소들을 담을 배열
        const consecutiveGroups = [];
        let currentGroup = [identifyElements[0]];
        let currentIdentifyValue = identifyElements[0].getAttribute('data-identifyelement');

        // 동일한 data-identifyelement 값을 가진 연속된 요소들을 그룹화
        for (let i = 1; i < identifyElements.length; i++) {
            const element = identifyElements[i];
            const elementIdentifyValue = element.getAttribute('data-identifyelement');

            if (elementIdentifyValue === currentIdentifyValue) {
                currentGroup.push(element);
            } else {
                if (currentGroup.length > 0) {
                    consecutiveGroups.push(currentGroup);
                }
                currentGroup = [element];
                currentIdentifyValue = elementIdentifyValue;
            }
        }
        
        // 마지막 그룹 추가
        if (currentGroup.length > 0) {
            consecutiveGroups.push(currentGroup);
        }

        // 가장 큰 그룹 선택 (가장 많은 연속된 요소를 가진 그룹)
        if (consecutiveGroups.length > 0) {
            const largestGroup = consecutiveGroups.reduce((max, group) => 
                group.length > max.length ? group : max
            , consecutiveGroups[0]);

            // 선택된 그룹의 요소들을 하나의 div로 합치기
            const combinedElement = document.createElement('div');
            combinedElement.setAttribute('data-translation-type', 'latest');
            
            largestGroup.forEach(element => {
                // gmail_attr 클래스를 가진 요소 제거
                const gmailAttrs = element.querySelectorAll('.gmail_attr');
                gmailAttrs.forEach(attr => attr.remove());
                
                // 내용 복사
                const clonedElement = element.cloneNode(true);
                combinedElement.appendChild(clonedElement);
            });

            console.log('Found consecutive elements with same data-identifyelement value:', currentIdentifyValue);
            return combinedElement;
        }
    }

    // 3. 클래스가 없는 직계 자식 div들 찾기
    const directChildDivs = Array.from(container.children).filter(child => {
        if (child.tagName !== 'DIV') return false;
        
        // 무시해야 할 요소 체크
        const shouldSkip = 
            child.className.includes('korean-translation') ||
            child.className.includes('translation-loading') ||
            child.className.includes('gmail_attr') ||
            child.className.includes('mail-footer') ||
            child.className.includes('xm_mail_oringinal_describe') ||
            child.id === 'original-content' ||
            child.id === 'QQMailSignature' ||
            child.querySelector('blockquote') ||
            child.textContent.includes('原始邮件');

        // 의미 있는 텍스트가 있고, 무시하지 않아야 할 요소만 선택
        return !shouldSkip && child.textContent.trim();
    });

    if (directChildDivs.length > 0) {
        // 연속된 div들을 하나의 요소로 합치기
        const combinedElement = document.createElement('div');
        combinedElement.setAttribute('data-translation-type', 'latest');
        
        directChildDivs.forEach(div => {
            const clonedDiv = div.cloneNode(true);
            // blockquote와 gmail_attr 요소 제거
            const elementsToRemove = clonedDiv.querySelectorAll('blockquote, .gmail_attr');
            elementsToRemove.forEach(el => el.remove());
            combinedElement.appendChild(clonedDiv);
        });

        if (combinedElement.textContent.trim()) {
            console.log('Found direct child divs with content');
            return combinedElement;
        }
    }

    // 4. 첫 번째 blockquote 이전의 모든 내용을 찾기
    const firstBlockquote = container.querySelector('blockquote');
    if (firstBlockquote) {
        const latestContent = document.createElement('div');
        let currentNode = container.firstChild;
        
        while (currentNode && currentNode !== firstBlockquote) {
            // 무시해야 할 요소 체크
            if (currentNode.nodeType === Node.ELEMENT_NODE) {
                const shouldSkip = 
                    currentNode.tagName === 'BLOCKQUOTE' ||
                    currentNode.id === 'original-content' ||
                    currentNode.id === 'QQMailSignature' ||
                    currentNode.className.includes('mail-footer') ||
                    currentNode.className.includes('gmail_') ||
                    currentNode.className.includes('gmail_attr') ||
                    currentNode.className.includes('korean-translation') ||
                    currentNode.className.includes('translation-loading') ||
                    currentNode.className.includes('xm_mail_oringinal_describe') ||
                    currentNode.textContent.includes('原始邮件');
                
                if (!shouldSkip) {
                    // blockquote가 아닌 경우에만 추가
                    const clonedNode = currentNode.cloneNode(true);
                    // 복제된 노드 내의 blockquote와 gmail_attr 요소들도 제거
                    const nestedElementsToRemove = clonedNode.querySelectorAll('blockquote, .gmail_attr');
                    nestedElementsToRemove.forEach(el => el.remove());
                    latestContent.appendChild(clonedNode);
                }
            } else if (currentNode.nodeType === Node.TEXT_NODE && currentNode.textContent.trim()) {
                latestContent.appendChild(currentNode.cloneNode(true));
            }
            currentNode = currentNode.nextSibling;
        }

        if (latestContent.textContent.trim()) {
            console.log('Latest response found before blockquote');
            latestContent.setAttribute('data-translation-type', 'latest');
            return latestContent;
        }
    }

    // 5. 전체 컨테이너의 첫 번째 의미 있는 텍스트 블록 찾기
    const children = Array.from(container.childNodes);
    const latestContent = document.createElement('div');
    
    for (const child of children) {
        // 이미 번역된 요소나 로딩 인디케이터는 건너뛰기
        if (child.nodeType === Node.ELEMENT_NODE && (
            child.tagName === 'BLOCKQUOTE' ||
            child.className.includes('korean-translation') ||
            child.className.includes('translation-loading') ||
            child.className.includes('gmail_attr') ||
            child.className.includes('xm_mail_oringinal_describe')
        )) {
            continue;
        }

        // 무시해야 할 요소 체크
        if (child.nodeType === Node.ELEMENT_NODE && (
            child.id === 'original-content' ||
            child.id === 'QQMailSignature' ||
            child.className.includes('mail-footer') ||
            child.className.includes('gmail_') ||
            child.textContent.includes('原始邮件')
        )) {
            continue;
        }

        // blockquote나 gmail_attr이 포함된 요소는 건너뛰기
        if (child.nodeType === Node.ELEMENT_NODE && 
            (child.querySelector('blockquote') || child.querySelector('.gmail_attr'))) {
            continue;
        }

        // 의미 있는 내용이 있는 노드만 추가
        if ((child.nodeType === Node.ELEMENT_NODE && child.textContent.trim()) ||
            (child.nodeType === Node.TEXT_NODE && child.textContent.trim())) {
            const clonedNode = child.cloneNode(true);
            // 복제된 노드 내의 blockquote와 gmail_attr 요소들도 제거
            if (clonedNode.nodeType === Node.ELEMENT_NODE) {
                const nestedElementsToRemove = clonedNode.querySelectorAll('blockquote, .gmail_attr');
                nestedElementsToRemove.forEach(el => el.remove());
            }
            latestContent.appendChild(clonedNode);
            break; // 첫 번째 의미 있는 텍스트 블록만 가져오기
        }
    }

    if (latestContent.textContent.trim()) {
        console.log('Latest response found in first meaningful block');
        latestContent.setAttribute('data-translation-type', 'latest');
        return latestContent;
    }

    console.log('No valid content found for translation');
    return null;
}

// 텍스트 수집 함수 수정
function collectText(element) {
    // 최신 답변인 경우에만 처리
    if (element.getAttribute('data-translation-type') !== 'latest') {
        return [];
    }

    let texts = [];
    
    // HTML 태그 제거 및 텍스트 정리
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = element.innerHTML;
    
    // 불필요한 요소 제거
    const elementsToRemove = tempDiv.querySelectorAll('.mail-footer, #QQMailSignature, #original-content');
    elementsToRemove.forEach(el => el.remove());
    
    // 첫 번째 blockquote 찾기
    const firstBlockquote = tempDiv.querySelector('blockquote');
    let content = '';
    
    if (firstBlockquote) {
        // blockquote 이전의 모든 내용 수집
        let currentNode = tempDiv.firstChild;
        while (currentNode && currentNode !== firstBlockquote) {
            if (currentNode.nodeType === Node.TEXT_NODE) {
                content += currentNode.textContent;
            } else if (currentNode.nodeType === Node.ELEMENT_NODE) {
                content += currentNode.textContent;
            }
            currentNode = currentNode.nextSibling;
        }
    } else {
        // blockquote가 없는 경우 전체 내용 사용
        content = tempDiv.textContent;
    }
    
    // 텍스트 정리
    const cleanText = content
        .trim()
        .replace(/\s+/g, ' ')  // 연속된 공백 제거
        .replace(/[\r\n]+/g, '\n');  // 연속된 줄바꿈 정리
    
    if (cleanText) {
        // 한국어 감지 (한글 정규식)
        const koreanRegex = /[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/g;
        const koreanMatches = cleanText.match(koreanRegex) || [];
        const koreanCharCount = koreanMatches.length;
        const totalCharCount = cleanText.length;
        
        // 한국어 비율 계산 (한글 문자가 전체 텍스트의 30% 미만인 경우 번역 진행)
        const koreanRatio = koreanCharCount / totalCharCount;
        
        if (koreanRatio < 0.3) {
            texts.push(cleanText);
            console.log("한국어 비율이 낮아 번역 진행:", koreanRatio);
        } else {
            console.log("한국어 비율이 높아 번역 건너뜀:", koreanRatio);
            isTranslationCompleted = true;
        }
    } else {
        // 텍스트가 없는 경우
        texts.push("번역이 되지 않는 텍스트입니다.");
        isTranslationCompleted = true;
    }
    
    return texts;
}

// 번역 결과를 페이지에 삽입하는 함수 수정
function insertTranslation(translation) {
    if (!checkExtensionContext()) return false;
    
    const container = document.querySelector('#ticket_original_request');
    if (!container) {
        if (insertAttempts < MAX_INSERT_ATTEMPTS) {
            console.log(`Insert attempt ${insertAttempts + 1}/${MAX_INSERT_ATTEMPTS} failed, retrying in 1 second...`);
            insertAttempts++;
            setTimeout(() => insertTranslation(translation), 1000);
            return false;
        }
        console.log('Max insert attempts reached, giving up');
        return false;
    }

    try {
        // 이미 번역이 삽입되어 있는지 확인
        let existingTranslation = container.querySelector('.korean-translation');
        let existingLoading = container.querySelector('.translation-loading');
        
        if (existingLoading) {
            existingLoading.remove();
        }

        if (existingTranslation) {
            existingTranslation.textContent = translation;
            existingTranslation.classList.add('show');
            console.log("Translation updated successfully");
            return true;
        }

        // 번역 결과를 표시할 새로운 div 생성
        const translationDiv = document.createElement('div');
        translationDiv.className = 'korean-translation';
        translationDiv.textContent = translation;

        try {
            // ticket_original_request의 첫 번째 자식으로 삽입
            container.insertBefore(translationDiv, container.firstChild);
            
            // 애니메이션을 위해 약간의 지연 후 show 클래스 추가
            setTimeout(() => {
                translationDiv.classList.add('show');
            }, 10);
            
            console.log("Translation inserted successfully");
            return true;
        } catch (insertError) {
            console.error("Error during insertion:", insertError);
            return false;
        }
    } catch (error) {
        console.error("Error inserting translation:", error);
        return false;
    }
}

// 메시지 전송 함수
function sendMessageToBackground(message) {
    return new Promise((resolve, reject) => {
        if (!checkExtensionContext()) {
            reject(new Error('Extension context is invalid'));
            return;
        }

        try {
            chrome.runtime.sendMessage(message, function(response) {
                if (chrome.runtime.lastError) {
                    console.error('메시지 전송 오류:', chrome.runtime.lastError);
                    reject(chrome.runtime.lastError);
                    return;
                }
                if (!checkExtensionContext()) {
                    reject(new Error('Extension context became invalid'));
                    return;
                }
                console.log('메시지가 성공적으로 전송됨:', response);
                resolve(response);
            });
        } catch (error) {
            console.error('메시지 전송 중 예외 발생:', error);
            isExtensionValid = false;
            reject(error);
        }
    });
}

// URL 변경 감지 및 처리 함수
function handleUrlChange() {
    console.log("URL changed, resetting state...");
    // 상태 초기화
    isTranslationCompleted = false;
    insertAttempts = 0;
    messageProcessingState = {
        isProcessing: false,
        lastProcessedTime: null,
        retryCount: 0,
        maxRetries: 3
    };

    // 기존 번역 및 로딩 요소 제거
    const existingTranslation = document.querySelector('.korean-translation');
    const existingLoading = document.querySelector('.translation-loading');
    const existingTranslatedTitle = document.querySelector('.translated-title');
    if (existingTranslation) existingTranslation.remove();
    if (existingLoading) existingLoading.remove();
    if (existingTranslatedTitle) existingTranslatedTitle.remove();

    // 새로운 번역 프로세스 시작
    setTimeout(() => {
        if (checkExtensionContext()) {
            translateTitle(); // URL 변경 시에도 제목 번역 실행
            processTranslation();
        }
    }, 1000);
}

// URL 변경 감지를 위한 옵저버 설정
function setupUrlChangeObserver() {
    let lastUrl = location.href;
    
    // URL 변경 감지를 위한 MutationObserver
    const observer = new MutationObserver(() => {
        if (location.href !== lastUrl) {
            lastUrl = location.href;
            handleUrlChange();
        }
    });

    // 전체 document 대신 body만 관찰
    observer.observe(document.body, { 
        childList: true,
        subtree: false // 하위 트리 감시 비활성화
    });
}

// DOM이 로드된 후 실행
let initializationTimer = null;
window.addEventListener('load', () => {
    console.log("Window loaded");
    insertStyles();
    setupUrlChangeObserver();
    
    // 이전 타이머가 있다면 제거
    if (initializationTimer) {
        clearTimeout(initializationTimer);
    }
    
    // 한 번만 실행되도록 설정
    initializationTimer = setTimeout(() => {
        if (!isTranslationCompleted && checkExtensionContext()) {
            translateTitle(); // 제목 번역 실행
            processTranslation();
            processPastQueries();
        }
        initializationTimer = null;
    }, 1000);
});

// History API 변경 감지
window.addEventListener('popstate', () => {
    handleUrlChange();
});

// 단일 번역 처리 함수 수정
async function processTranslation() {
    if (!checkExtensionContext()) {
        console.log("Extension context is invalid, stopping...");
        return;
    }

    if (isTranslationCompleted) {
        console.log("Translation already completed, skipping...");
        return;
    }

    const container = document.querySelector('#ticket_original_request');
    if (!container) {
        console.log("Container not found, retrying...");
        if (insertAttempts < MAX_INSERT_ATTEMPTS) {
            insertAttempts++;
            setTimeout(() => processTranslation(), 1000);
        }
        return;
    }

    const targetElement = findTargetElement();
    if (!targetElement) {
        console.log("Target element not found yet");
        if (insertAttempts < 3) {
            insertAttempts++;
            setTimeout(() => {
                if (!isTranslationCompleted) {
                    processTranslation();
                }
            }, 3000);
        } else {
            console.log("Max retry attempts reached, stopping translation attempts");
        }
        return;
    }

    console.log("Target element found!");
    
    // 모든 의미 있는 텍스트 수집
    const texts = collectText(targetElement);
    const textContent = texts.join('\n').trim();
    
    if (!textContent) {
        console.log("Text content is empty, skipping...");
        return;
    }
    
    // Latent 답변 데이터를 JSON 형태로 콘솔에 출력
    const latentData = {
        type: 'translation',
        content: textContent,
        timestamp: new Date().toISOString(),
        source: 'latent_response',
        metadata: {
            url: window.location.href,
            elementType: targetElement.getAttribute('data-translation-type')
        }
    };
    
    console.log("Latent Response Data:", JSON.stringify(latentData, null, 2));
    
    // 기존 로딩 인디케이터와 번역 제거
    const existingLoading = container.querySelector('.translation-loading');
    const existingTranslation = container.querySelector('.korean-translation');
    if (existingLoading) existingLoading.remove();
    if (existingTranslation) existingTranslation.remove();
    
    // 새로운 로딩 인디케이터 추가
    const loadingIndicator = createLoadingIndicator();
    container.insertBefore(loadingIndicator, container.firstChild);
    
    console.log("Text Content:", textContent);

    try {
        console.log("Sending translation request...");
        const response = await sendMessageToBackground({
            action: "queryChatGPT",
            query: textContent,
            type: 'translation'
        });
        
        console.log("Response received:", response);
        
        // 로딩 인디케이터 제거
        const currentLoading = container.querySelector('.translation-loading');
        if (currentLoading) currentLoading.remove();
        
        if (response && response.success && response.translation) {
            const insertSuccess = insertTranslation(response.translation);
            if (insertSuccess) {
                isTranslationCompleted = true;
                console.log("Translation completed successfully!");
            }
        }
    } catch (error) {
        console.error('Translation error:', error);
        const currentLoading = container.querySelector('.translation-loading');
        if (currentLoading) currentLoading.remove();
        isTranslationCompleted = false;
    }
}

// 과거 고객 문의 수집 함수 수정
function collectCustomerQueries(container) {
    const queries = [];
    const elements = container.querySelectorAll('.customer-query, .agent-response');
    elements.forEach(element => {
        queries.push(element.textContent.trim());
    });
    return queries;
}

// 번역 완료 후 과거 문의 요약 처리
async function processPastQueries() {
    const container = document.querySelector('#ticket_original_request');
    if (!container) {
        console.log('Ticket container not found');
        return;
    }

    const queries = collectCustomerQueries(container);
    if (queries.length === 0) {
        console.log('No past queries found');
        return;
    }

    const queryText = queries.join('\n');
    console.log('Collected past queries:', queryText);

    try {
        const response = await sendMessageToBackground({
            action: "queryChatGPT",
            query: queryText,
            type: 'summary'
        });
        console.log('Summary response received:', response);
        if (response && response.success) {
            showSummarySidebar(response.translation);
        }
    } catch (error) {
        console.error('Error processing past queries:', error);
    }
}

// 사이드바 생성 및 표시 함수
function showSummarySidebar(summaryText) {
    const sidebar = document.createElement('div');
    sidebar.id = 'summary-sidebar';
    sidebar.style.position = 'fixed';
    sidebar.style.right = '0';
    sidebar.style.top = '0';
    sidebar.style.width = '300px';
    sidebar.style.height = '100%';
    sidebar.style.backgroundColor = '#f5f5f5';
    sidebar.style.borderLeft = '1px solid #ccc';
    sidebar.style.overflowY = 'auto';
    sidebar.style.padding = '10px';
    sidebar.innerHTML = `<h2>Summary</h2><p>${summaryText}</p>`;
    document.body.appendChild(sidebar);
}

// 메시지 수신 리스너 수정
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (!checkExtensionContext()) {
        console.log('확장 프로그램 컨텍스트가 유효하지 않음');
        return;
    }

    console.log("메시지 수신:", request);
    
    if (messageProcessingState.isProcessing) {
        console.log('이전 메시지 처리 중...');
        return;
    }

    messageProcessingState.isProcessing = true;

    try {
        // 제목 번역 처리
        if (request.action === "title" && request.translation) {
            const titleElement = document.querySelector('.ticket-subject-heading.text--large.text--bold');
            if (titleElement) {
                // 이미 있는 번역된 제목이나 로딩 표시 제거
                const existingTranslation = document.querySelector('.translated-title');
                const existingLoading = document.querySelector('.translation-loading');
                if (existingTranslation) existingTranslation.remove();
                if (existingLoading) existingLoading.remove();

                // 새로운 번역된 제목 추가
                const translatedTitleDiv = document.createElement('div');
                translatedTitleDiv.className = 'translated-title';
                translatedTitleDiv.textContent = request.translation;
                titleElement.parentNode.insertBefore(translatedTitleDiv, titleElement.nextSibling);
                console.log("제목 번역 삽입 완료");
            }
            sendResponse({ success: true });
        }
        // 일반 번역 처리
        else if (request.action === "translation" && request.translation) {
            console.log("Latent 번역 수신, 삽입 시도 중...");
            
            insertAttempts = 0;
            const insertSuccess = insertTranslation(request.translation);
            
            if (insertSuccess) {
                isTranslationCompleted = true;
                messageProcessingState.lastProcessedTime = Date.now();
                console.log("Latent 번역 삽입 완료");
                sendResponse({ success: true });
            } else {
                isTranslationCompleted = false;
                messageProcessingState.retryCount++;
                console.log(`Latent 번역 삽입 실패 (재시도 ${messageProcessingState.retryCount}/${messageProcessingState.maxRetries})`);
                
                if (messageProcessingState.retryCount < messageProcessingState.maxRetries) {
                    setTimeout(() => {
                        insertTranslation(request.translation);
                    }, 1000);
                }
                sendResponse({ success: false });
            }
        }
        // 개별 번역 처리
        else if (request.action === "individual_translation" && request.translation) {
            try {
                messageProcessingState.isProcessing = true;
                const translationResult = document.getElementById('translation-result');
                if (translationResult) {
                    // 로딩 인디케이터 제거
                    const loadingIndicator = translationResult.querySelector('.translation-loading');
                    if (loadingIndicator) {
                        loadingIndicator.remove();
                    }
                    
                    // 번역 결과가 undefined가 아닌지 확인
                    if (request.translation !== undefined) {
                        // 번역 결과를 div로 감싸서 표시
                        translationResult.innerHTML = `<div class="translation-content">${request.translation}</div>`;
                        messageProcessingState.lastProcessedTime = Date.now();
                        console.log("개별 번역 완료:", request.translation);
                    } else {
                        console.error("번역 결과가 undefined입니다.");
                        translationResult.innerHTML = '<div class="error-message">번역 결과를 가져오는데 실패했습니다.</div>';
                    }
                }
            } catch (error) {
                console.error('개별 번역 처리 중 오류 발생:', error);
                const translationResult = document.getElementById('translation-result');
                if (translationResult) {
                    translationResult.innerHTML = '<div class="error-message">번역 처리 중 오류가 발생했습니다.</div>';
                }
            } finally {
                messageProcessingState.isProcessing = false;
            }
        }
        // 요약 처리
        else if (request.action === "summary" && request.translation) {
            console.log("Summary received, displaying in sidebar...");
            const summaryResult = document.getElementById('summary-result');
            if (summaryResult) {
                summaryResult.innerHTML = request.translation;
            }
            sendResponse({ success: true });
            return;
        }
    } catch (error) {
        console.error('메시지 처리 중 오류 발생:', error);
        sendResponse({ success: false, error: error.message });
    } finally {
        messageProcessingState.isProcessing = false;
    }

    return true; // 비동기 응답을 위해 true 반환
});

// 제목 번역 함수
async function translateTitle() {
    const titleElement = document.querySelector('.ticket-subject-heading.text--large.text--bold');
    if (!titleElement) {
        console.log('제목 요소를 찾을 수 없습니다.');
        return;
    }

    const originalTitle = titleElement.textContent.trim();
    
    // 이미 번역된 제목이 있는지 확인
    if (titleElement.nextElementSibling?.classList.contains('translated-title')) {
        console.log('이미 번역된 제목이 존재합니다.');
        return;
    }

    // 한국어 감지
    const koreanRegex = /[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/;
    if (koreanRegex.test(originalTitle)) {
        console.log('한국어 제목 감지됨, 번역 무시');
        return;
    }

    try {
        // 로딩 표시 추가
        const loadingDiv = document.createElement('div');
        loadingDiv.className = 'translation-loading';
        loadingDiv.innerHTML = '<div class="loading-spinner"></div><span>제목 번역 중...</span>';
        titleElement.parentNode.insertBefore(loadingDiv, titleElement.nextSibling);

        const response = await sendMessageToBackground({
            action: "queryChatGPT",
            query: originalTitle,
            type: 'title'
        });

        // 로딩 표시 제거
        loadingDiv.remove();

        // 응답 처리는 메시지 리스너에서 처리됨
    } catch (error) {
        console.error('제목 번역 중 오류 발생:', error);
        // 로딩 표시 제거
        const loadingDiv = titleElement.nextElementSibling;
        if (loadingDiv?.classList.contains('translation-loading')) {
            loadingDiv.remove();
        }
    }
}
