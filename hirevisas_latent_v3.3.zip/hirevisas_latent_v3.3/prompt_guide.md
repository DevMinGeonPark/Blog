# 프롬프트 추가 가이드

## 개요
이 문서는 Hirevisas 프로젝트의 프롬프트 시스템에 새로운 프롬프트를 추가하는 방법을 설명합니다.


## 수정 순서
1. GPT에게 프롬프트를 넣어서 질문을 기다리게한다
2. GPT에게 번역할 js 코드를 제공한다 (e.g. commonGuidelines.js를 복사해서 넣기)
3. 엔터를쳐서 아래에 필요한 프롬프트를 입력한다. (e.g. Korean Univ를 고려대학교로 번역해)
4. 프롬프트를 수정하고 저장한다 (Ctrl + s)
5. Chrome Extenstion에 가서 업데이트를 누른다
6. 새로고침하여 동작을 확인한다.

## API 키 변경 방법
1. https://openai.com/index/openai-api/ 접속
2. Login API Platform
3. https://platform.openai.com/docs/overview에 접속되면 설정 진입 (톱니바퀴 표시)
4. API Keys에서 API 키 생성 혹은 있으면 복사
5. 복사한 API 키를 [backgroundScript.js](./backgroundScript.js)에서 API_KEY에 삽입
6. 반드시 API 키는 아래의 형식을 지켜야함 (따옴표 주의)
형식 : API_KEY = "키내용"

## 프롬프트 구조
프롬프트는 다음과 같은 기본 구조를 따릅니다:

1. **공통 가이드라인** ([commonGuidelines.js](./prompts/commonGuidelines.js))
   - 모든 프롬프트에서 공유되는 기본 규칙들
   - 줄바꿈, 간격, 강조, 보존 규칙 등 포함

2. **특정 프롬프트 파일** 
   - 특정 작업에 대한 구체적인 프롬프트 로직
   - 공통 가이드라인을 확장하여 사용
   - 최신대화 번역 ([latentPrompt.js](./prompts/latentPrompt.js))
   - 이메일 대화 내역 번역 프롬프트 ([latentPrompt.js](./prompts/latentPrompt.js))
   - 제목 번역 프롬프트 ([titlePrompt.js](./prompts/titlePrompt.js))
   - 요약 번역 프롬프트 ([summaryPrompt.js](./prompts/summaryPrompt.js))
   - 제목 번역 프롬프트 ([titlePrompt.js](./prompts/titlePrompt.js))
   - 요약 번역 프롬프트 ([summaryPrompt.js](./prompts/summaryPrompt.js))

3. **단어 추가 예시** ([commonGuidelines.js](./prompts/commonGuidelines.js))
   ```javascript
   // 단어 사용 규칙에 새로운 규칙 추가
   const wordUsageRules = {
       immigration: "- Use '출입국' instead of '이민국'",
       company: "- Keep 'Hirevisa' in original form", 
       other: "- Keep other specific terms in original form",
       enrollment: "Translate 'Certificate of Enrollment' to '재학증명서'",
       koreaUniversity: "Translate 'Korea University' to '고려대학교'",
       // 새로운 규칙 추가 예시
       newRule: "- Translate 'Example Term' to '예시 용어'"
   };
   ```


## 프롬프트 수정 방법

### 1. 기존 프롬프트 파일 수정
기존 프롬프트 파일에 새로운 기능을 추가하는 방법입니다:
이는 구체적 프롬프트 수정 방법입니다.

```javascript
// 기존 규칙에 새로운 규칙 추가
const existingRules = {
    // ... 기존 규칙들
    newRule: "- 새로운 규칙 추가"
};

// 새로운 예시 추가
const exampleText = {
    // ... 기존 예시들
    newExample: "새로운 예시 텍스트"
};

// 시스템 메시지에 새로운 내용 추가
export function createExistingPrompt(query) {
    const systemMessage = {
        role: "system",
        content: `[기존 시스템 프롬프트 내용]

${existingRules.newRule}

${commonGuidelines.formatting.lineBreaks}
${commonGuidelines.formatting.spacing}
${commonGuidelines.formatting.emphasis}
${commonGuidelines.content.preserve}
${commonGuidelines.content.style}
${commonGuidelines.content.wordUsage}
${commonGuidelines.instructions.exclude}

IMPORTANT: 
${commonGuidelines.important}

Example input: [Original text]
Example output: "${exampleText.newExample}"`
    };

    const userMessage = {
        role: "user",
        content: `[${query}]`
    };

    return [systemMessage, userMessage];
}
```

### 2. 프롬프트 선택 기준
새로운 기능을 추가할 때는 다음 기준에 따라 적절한 프롬프트를 선택하세요:

1. **latentPrompt.js** 선택 시:
   - 최신 번역 박스에 표시되는 내용
   - 실시간 번역 결과
   - 사용자 입력에 대한 즉각적인 응답

2. **titlePrompt.js** 선택 시:
   - 제목 관련 번역
   - 짧은 텍스트의 번역
   - 특별한 포맷팅이 필요한 제목

3. **translationPrompt.js** 선택 시:
   - 사이드바의 일반적인 번역
   - 긴 텍스트의 번역
   - 구조화된 문서 번역

## 프롬프트 수정 규칙

### 1. 가이드라인 구성
- 기존 규칙과 일관성 유지
- 새로운 규칙은 하이픈(-)으로 시작
- 규칙은 간단하고 이해하기 쉽게 작성

### 2. 예시 텍스트
- 실제 사용 사례를 반영한 예시 포함
- 기존 예시와 동일한 형식 유지
- 새로운 기능을 잘 보여주는 예시 선택

### 3. 시스템 메시지 구성
- 기존 역할 정의 유지
- 새로운 가이드라인 추가
- 공통 가이드라인 통합
- 중요 규칙 강조
- 관련 예시 포함

## GPT 프롬프트 예시
다음은 기존 프롬프트를 수정할 때 사용할 수 있는 GPT 프롬프트입니다:

```
다음 요구사항에 맞춰 기존 프롬프트를 수정해주세요:

1. 수정할 프롬프트: [latentPrompt.js / titlePrompt.js / translationPrompt.js]
2. 추가할 기능: [새로운 기능 설명]
3. 입력 형식: [입력 형식 설명]
4. 출력 형식: [출력 형식 설명]
5. 특별 규칙: [특별 규칙 설명]
6. 예시: [예시 입력과 출력]

기존 프롬프트 구조를 유지하면서 다음 사항을 포함해주세요:
- commonGuidelines.js의 규칙들을 활용
- 기존 시스템 메시지와의 일관성 유지
- 새로운 가이드라인 추가
- 실제 사용 사례를 반영한 예시
- 중요 규칙 강조

프롬프트는 기존 JavaScript 모듈을 수정하는 형태로 작성되어야 합니다.