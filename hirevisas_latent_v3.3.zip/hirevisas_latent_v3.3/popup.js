document.getElementById("query-btn").addEventListener("click", () => {
    const query = document.getElementById("query-input").value;
    chrome.runtime.sendMessage({ action: "queryChatGPT", query: query }, (response) => {
      console.log("Response from background:", response);
    });
  });
  
document.getElementById("toggle-summary-sidebar").addEventListener("change", (event) => {
    const isVisible = event.target.checked;
    chrome.runtime.sendMessage({ action: "toggleSummarySidebar", visible: isVisible }, (response) => {
        console.log("Summary sidebar visibility changed:", response);
    });
});
  