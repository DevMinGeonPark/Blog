console.log("Background script loaded!");

let messageProcessingState = {
    isProcessing: false,
    lastProcessedTime: null,
    retryCount: 0,
    maxRetries: 3
};

// API Key!
const API_KEY = "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"; // 실제 API 키로 교체 필요

// 프롬프트 생성 함수 임포트
import { createPrompt } from './prompts/index.js';

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log("Received message in background:", request);
    
    if (messageProcessingState.isProcessing) {
        console.log('이전 메시지 처리 중...');
        sendResponse({ success: false, error: "Previous message is still processing" });
        return false;
    }
    
    if (request.action === "queryChatGPT") {
        const query = request.query;
        const type = request.type || 'translation';
        const isSidebarTranslation = request.isSidebarTranslation || false;

        console.log("Processing request type:", type);
        const prompt = createPrompt(query, type);
        console.log("Generated prompt:", prompt);

        // API 요청 데이터 준비
        const requestBody = {
            model: "gpt-4o-mini",
            messages: prompt,
            temperature: 0.3,
            max_tokens: 1000
        };

        // 요청 전 데이터 로깅
        console.log("Sending request with data:", JSON.stringify(requestBody, null, 2));

        // 비동기 처리를 위한 Promise 반환
        fetch("https://api.openai.com/v1/chat/completions", {
            method: "POST",
            headers: {
                "Authorization": `Bearer ${API_KEY}`,
                "Content-Type": "application/json",
            },
            body: JSON.stringify(requestBody)
        })
        .then(async response => {
            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                console.error("API Response:", {
                    status: response.status,
                    statusText: response.statusText,
                    error: errorData
                });
                throw new Error(`HTTP error! status: ${response.status}, message: ${JSON.stringify(errorData)}`);
            }
            return response.json();
        })
        .then(data => {
            console.log("API Response:", data);
            try {
                let responseContent = null;
                
                // 응답 데이터 검증
                if (!data || !data.choices || !data.choices[0]) {
                    throw new Error("Invalid API response structure");
                }

                // 응답 내용 추출
                const choice = data.choices[0];
                if (choice.message && choice.message.content) {
                    responseContent = choice.message.content;
                } else {
                    throw new Error("No content found in API response");
                }

                // 응답 내용이 비어있는지 확인
                if (!responseContent || responseContent.trim() === '') {
                    throw new Error("Empty translation result");
                }

                // 응답 내용 정리
                responseContent = responseContent
                    .replace(/^["']|["']$/g, '') // 시작과 끝의 따옴표 제거
                    .replace(/\\n/g, '\n') // \n 문자열을 실제 줄바꿈으로 변환
                    .replace(/\\/g, '') // 남은 백슬래시 제거
                    .trim(); // 앞뒤 공백 제거

                // 응답이 유효한지 한 번 더 확인
                if (!responseContent || responseContent === 'undefined' || responseContent === 'null') {
                    throw new Error("Invalid translation result");
                }

                // 응답 전송
                const actionType = type === 'summary' ? "summary" : 
                                 type === 'latent' ? "latent" :
                                 type === 'title' ? "title" :
                                 type === 'individual_translation' ? "individual_translation" : "translation";
                
                console.log("Sending translation:", responseContent);
                
                if (responseContent && typeof responseContent === 'string') {
                    chrome.tabs.sendMessage(sender.tab.id, {
                        action: actionType,
                        translation: responseContent,
                        success: true
                    });
                    sendResponse({ success: true, translation: responseContent });
                } else {
                    throw new Error("Invalid response content type");
                }
            } catch (error) {
                console.error("Error processing API response:", error);
                const errorMessage = error.message || "Unknown error occurred";
                chrome.tabs.sendMessage(sender.tab.id, {
                    action: type === 'summary' ? "summary" : 
                            type === 'latent' ? "latent" :
                            type === 'individual_translation' ? "individual_translation" : "translation",
                    translation: `번역 중 오류가 발생했습니다: ${errorMessage}`,
                    success: false
                });
                sendResponse({ success: false, error: errorMessage });
            }
        })
        .catch(error => {
            console.error("API Error:", error);
            const errorMessage = error.message || "API 요청 중 오류가 발생했습니다";
            chrome.tabs.sendMessage(sender.tab.id, {
                action: type === 'summary' ? "summary" : 
                        type === 'latent' ? "latent" :
                        type === 'individual_translation' ? "individual_translation" : "translation",
                translation: `번역 중 오류가 발생했습니다: ${errorMessage}`,
                success: false
            });
            sendResponse({ success: false, error: errorMessage });
        });

        return true; // 비동기 응답을 위해 true 반환
    }
    
    if (request.action === "toggleSummarySidebar") {
        sendResponse({ success: true });
        return false;
    }
    
    sendResponse({ success: false, error: "Unknown action" });
    return false;
});
  